# WEB PAGE for Controlling The Movement Of The Robot 

This repository is about creating two web pages for controlling the movment of the robot as a FULL STACK developer.

## Description

In this web page we will control the angles of the motors and the range of servo motor is from 0 to 180. Also, the dirction of the movement such as right left and so on.

## Getting Started

### Direction Control 

* index.html.
* style.html. 
* script.js
* index.php
* request.php
* pic.jpg

### Full Controlling

* combine.html
* combine.css
* combine.js
* combine.php
* pic2.jpg


### Pictures
<img width="970" alt="Screen Shot 2021-06-24 at 12 18 06 AM" src="https://user-images.githubusercontent.com/66702376/123169346-d8e9c200-d481-11eb-9ec0-ddac00036aa7.png">
<img width="1297" alt="Screen Shot 2021-06-24 at 12 18 30 AM" src="https://user-images.githubusercontent.com/66702376/123169444-fc147180-d481-11eb-87d2-9a5bfdd14424.png">





## NOTE

* you need to use server such as xampp or mamp.I faced a problem many times and it was - Error Code: 1364. Field ’emp_id’ doesn’t have a default value. To solve the problem just create a default value for your column data.



## Any Question

Please if you have any question just contact me



## Author

 I'm an Electrical and Computer Engineer student at KAU in KSA I'm a self learning person. I love programming and electronics.<br/> 
 [email:asma-sarouji@hotmail.com]<br/>
 [My LinkedIn Account ](https://www.linkedin.com/in/asma-sarouji-265484149/)<br/>
 [My Instagram Account](https://www.instagram.com/samaabdullah98/)<br/>







## Acknowledgments

THIS WORK WAS BASED ON THE TRAINING IN SMART METHODS SAUDI COMPANY.
* [Smart Methods Page](https://www.s-m.com.sa)
* [youtube of smart methods](https://youtu.be/0iPByiZVHFw)
